const F="data-browser-bridge-id",j=["a[href]","button","input","textarea","select","[role='button']","[role='link']","[role='menuitem']","[role='tab']","[role='option']","[role='checkbox']","[role='radio']","[role='textbox']","[onclick]","[contenteditable='true']"].join(","),_e=[/delete/i,/remove/i,/destroy/i,/drop/i,/pay/i,/purchase/i,/submit/i,/send/i,/publish/i,/approve/i,/reject/i,/删除/,/移除/,/支付/,/购买/,/提交/,/发送/,/发布/,/审批/,/通过/,/拒绝/];let H=0;const M=[];let Y=!1;document.addEventListener("click",e=>{if(!Y)return;const t=e.target;if(!t)return;const n=E(t),r=Z(t);chrome.runtime.sendMessage({type:"browser_bridge_record_step",step:{action:"click",text:n||void 0,selector:n?void 0:r,url:location.href}})},!0);document.addEventListener("change",e=>{if(!Y)return;const t=e.target;if(!t)return;const n=Q(t),r=U(t),o=t.getAttribute("aria-label"),i=Z(t);chrome.runtime.sendMessage({type:"browser_bridge_record_step",step:{action:"type",value:n,placeholder:r||void 0,ariaLabel:o||void 0,selector:!r&&!o?i:void 0,url:location.href}})},!0);const Ae=console.error,Se=console.warn;console.error=(...e)=>{M.push({type:"error",message:e.join(" ")}),M.length>20&&M.shift(),Ae.apply(console,e)};console.warn=(...e)=>{M.push({type:"warn",message:e.join(" ")}),M.length>20&&M.shift(),Se.apply(console,e)};chrome.runtime.onMessage.addListener((e,t,n)=>{if((e==null?void 0:e.type)==="browser_bridge_ping")return n({ok:!0}),!0;if((e==null?void 0:e.type)==="browser_bridge_draw_overlay")return Me(),n({ok:!0}),!0;if((e==null?void 0:e.type)==="browser_bridge_remove_overlay")return ae(),n({ok:!0}),!0;if((e==null?void 0:e.type)==="browser_bridge_toggle_recording")return Y=!!e.enabled,n({ok:!0}),!0;if((e==null?void 0:e.type)==="agent_session_status")return A=!!e.active,z(A?"SESSION_ACTIVE":void 0),n({ok:!0}),!0;if((e==null?void 0:e.type)!=="browser_bridge_request")return(e==null?void 0:e.type)==="browser_bridge_confirm"?(he(String(e.reason??"高风险操作")).then(o=>n({confirmed:o})),!0):!1;const r=e.request;return console.log(`[BrowserBridge] 收到请求: ${r.tool}`,r.params),H++,z(r.tool,r.params),Re(r).then(o=>{console.log(`[BrowserBridge] 请求成功: ${r.tool}`),n({ok:!0,data:o})}).catch(o=>{const i=o instanceof Error?o.message:String(o);console.error(`[BrowserBridge] 请求失败: ${r.tool}`,i);const[s,c]=i.includes(": ")?i.split(/: (.*)/s,2):["INTERNAL_ERROR",i],d=Ce(r);n({ok:!1,error:{code:s,message:c||i,diagnostics:d}})}).finally(()=>{H--,z()}),!0});chrome.runtime.sendMessage({type:"get_agent_session_status"}).then(e=>{(e==null?void 0:e.active)!==void 0&&(A=!!e.active,A&&z("SESSION_ACTIVE"))});function Ce(e){const t={url:location.href,recentLogs:[...M]},n=e.params??{},r=String(n.elementId??""),o=String(n.selector??"");if(r){const i=document.querySelector(`[${F}="${S(r)}"]`);i&&(t.htmlSnippet=i.outerHTML.slice(0,1e3))}else if(o)try{const i=document.querySelector(o);i&&(t.htmlSnippet=i.outerHTML.slice(0,1e3))}catch{}return t}function Me(){ae();const e=document.createElement("div");e.id="browser-bridge-visual-mapping",e.style.cssText="position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 2147483646;",document.body.appendChild(e),L({visibleOnly:!0,viewportOnly:!0}).forEach((n,r)=>{const o=n.getBoundingClientRect(),i=document.createElement("div"),s=r+1;n.setAttribute("data-bb-temp-id",String(s)),i.style.cssText=`
      position: fixed;
      top: ${o.top}px;
      left: ${o.left}px;
      width: ${o.width}px;
      height: ${o.height}px;
      border: 2px solid #ef4444;
      background: rgba(239, 68, 68, 0.1);
      box-sizing: border-box;
      pointer-events: none;
    `;const c=document.createElement("div");c.innerText=String(s),c.style.cssText=`
      position: absolute;
      top: -20px;
      left: 0;
      background: #ef4444;
      color: white;
      font-size: 12px;
      padding: 0 4px;
      border-radius: 2px;
      line-height: 18px;
      white-space: nowrap;
    `,i.appendChild(c),e.appendChild(i)})}function ae(){const e=document.getElementById("browser-bridge-visual-mapping");e&&e.remove(),document.querySelectorAll("[data-bb-temp-id]").forEach(t=>{t.removeAttribute("data-bb-temp-id")})}let te=0;const ke=800;let A=!1,X=null;const Ie=5*60*1e3,ne={BROWSER_OPEN_URL:"打开链接",BROWSER_CLICK:"点击元素",BROWSER_TYPE:"输入文本",BROWSER_FIND:"查找元素",BROWSER_GET_PAGE_TEXT:"读取文本",BROWSER_GET_PAGE_MODEL:"解析页面数据",BROWSER_SCREENSHOT:"屏幕截图",BROWSER_EVALUATE:"执行脚本",BROWSER_WAIT_FOR:"等待元素",BROWSER_ACT:"执行操作",BROWSER_USE:"协议激活",SESSION_ACTIVE:"会话激活"};function z(e,t){if(H>0||A)te=Date.now(),Le(e,t),X&&clearTimeout(X),X=setTimeout(()=>{A&&(console.warn("[BrowserBridge] 自动关闭超时的持久化蒙层"),A=!1,re())},Ie);else{const n=Date.now()-te,r=Math.max(0,ke-n);setTimeout(()=>{H===0&&!A&&re()},r)}}function Le(e,t){let n=document.getElementById("browser-bridge-agent-overlay");if(n)n.style.display="flex",n.style.opacity="1";else{n=document.createElement("div"),n.id="browser-bridge-agent-overlay",n.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: 
        radial-gradient(circle at center, transparent 30%, rgba(0, 10, 20, 0.4) 100%),
        url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l25.98 15v30L30 60 4.02 45V15z' fill-opacity='0.05' fill='%2300ffff' fill-rule='evenodd'/%3E%3C/svg%3E");
      pointer-events: none;
      z-index: 2147483647;
      border: 1px solid rgba(0, 255, 255, 0.2);
      box-sizing: border-box;
      box-shadow: inset 0 0 150px rgba(0, 255, 255, 0.1);
      backdrop-filter: blur(2px) saturate(1.2);
      font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      padding: 40px;
      transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    `;const r=document.createElement("div");r.style.cssText=`
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      opacity: 0.03;
      pointer-events: none;
      font-family: monospace;
      font-size: 10px;
      color: #00ffff;
      overflow: hidden;
      white-space: nowrap;
      user-select: none;
    `;for(let p=0;p<20;p++){const w=document.createElement("div");w.innerText=Math.random().toString(2).substring(2).repeat(10),w.style.animation=`bb-data-stream ${10+Math.random()*20}s linear infinite`,w.style.opacity=(.2+Math.random()*.8).toString(),r.appendChild(w)}n.appendChild(r);const o=document.createElement("div");o.style.cssText=`
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 10px;
      background: linear-gradient(to bottom, 
        transparent, 
        rgba(255, 0, 255, 0.2), 
        rgba(0, 255, 255, 0.5), 
        rgba(255, 0, 255, 0.2), 
        transparent
      );
      box-shadow: 0 0 20px rgba(0, 255, 255, 0.4);
      animation: bb-scan 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
      opacity: 0.6;
    `;const i=document.createElement("div");i.style.cssText=`
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 15px;
      filter: drop-shadow(0 0 15px rgba(0, 255, 255, 0.4));
    `;const s=document.createElement("div");s.id="bb-status-badge",s.style.cssText=`
      display: flex;
      align-items: center;
      gap: 15px;
      background: rgba(0, 20, 40, 0.85);
      padding: 12px 25px;
      border-radius: 4px;
      border-left: 5px solid #00ffff;
      clip-path: polygon(10% 0, 100% 0, 100% 100%, 0 100%, 0 30%);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
      position: relative;
      overflow: hidden;
    `;const c=document.createElement("div");c.style.cssText=`
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(0, 255, 255, 0.2), transparent);
      animation: bb-glimmer 2s infinite;
    `,s.appendChild(c);const d=document.createElement("div");d.style.cssText=`
      width: 8px;
      height: 8px;
      background: #ff00ff;
      border-radius: 2px;
      box-shadow: 0 0 15px #ff00ff;
      animation: bb-glitch-blink 0.5s step-end infinite;
    `;const a=document.createElement("div");a.id="bb-status-text",a.style.cssText=`
      color: #00ffff;
      font-size: 14px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 3px;
      text-shadow: 2px 2px rgba(255, 0, 255, 0.5);
      animation: bb-glitch-text 3s infinite;
    `,a.innerText="智能协议激活中",s.appendChild(d),s.appendChild(a);const l=document.createElement("div");if(l.id="bb-log-container",l.style.cssText=`
      color: #00ffff;
      font-family: 'JetBrains Mono', 'Fira Code', monospace;
      font-size: 11px;
      background: rgba(0, 10, 20, 0.9);
      padding: 15px;
      border-radius: 4px;
      min-width: 280px;
      text-align: right;
      border: 1px solid rgba(0, 255, 255, 0.3);
      border-right: 4px solid #ff00ff;
      line-height: 1.8;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4);
    `,["top-left","top-right","bottom-left","bottom-right"].forEach(p=>{const w=document.createElement("div");w.style.cssText=`
        position: absolute;
        width: 80px;
        height: 80px;
        ${p.includes("top")?"top: 15px;":"bottom: 15px;"}
        ${p.includes("left")?"left: 15px;":"right: 15px;"}
      `;const B=document.createElement("div");B.style.cssText=`
        position: absolute;
        width: 100%;
        height: 100%;
        border-color: #00ffff;
        border-style: solid;
        border-width: 0;
        ${p.includes("top")?"border-top-width: 4px;":"border-bottom-width: 4px;"}
        ${p.includes("left")?"border-left-width: 4px;":"border-right-width: 4px;"}
        box-shadow: 0 0 15px rgba(0, 255, 255, 0.5);
      `;const D=document.createElement("div");D.style.cssText=`
        position: absolute;
        width: 40%;
        height: 40%;
        border-color: #ff00ff;
        border-style: solid;
        border-width: 0;
        ${p.includes("top")?"top: 8px; border-top-width: 2px;":"bottom: 8px; border-bottom-width: 2px;"}
        ${p.includes("left")?"left: 8px; border-left-width: 2px;":"right: 8px; border-right-width: 2px;"}
        opacity: 0.7;
      `,w.appendChild(B),w.appendChild(D),n==null||n.appendChild(w)}),!document.getElementById("bb-overlay-style")){const p=document.createElement("style");p.id="bb-overlay-style",p.textContent=`
        @keyframes bb-scan {
          0% { top: -10%; opacity: 0; }
          10% { opacity: 0.6; }
          90% { opacity: 0.6; }
          100% { top: 110%; opacity: 0; }
        }
        @keyframes bb-glitch-blink {
          0%, 100% { background: #00ffff; box-shadow: 0 0 15px #00ffff; }
          50% { background: #ff00ff; box-shadow: 0 0 15px #ff00ff; }
          25%, 75% { opacity: 0.5; }
        }
        @keyframes bb-glitch-text {
          0%, 100% { transform: translate(0); }
          33% { transform: translate(-2px, 1px); text-shadow: -2px 0 #ff00ff; }
          66% { transform: translate(2px, -1px); text-shadow: 2px 0 #00ffff; }
        }
        @keyframes bb-glimmer {
          0% { left: -100%; }
          100% { left: 100%; }
        }
        @keyframes bb-data-stream {
          0% { transform: translateY(0); }
          100% { transform: translateY(-100%); }
        }
        @keyframes bb-fade-in {
          from { opacity: 0; transform: scale(1.02); }
          to { opacity: 1; transform: scale(1); }
        }
      `,document.head.appendChild(p)}i.appendChild(s),i.appendChild(l),n.appendChild(o),n.appendChild(i),document.documentElement.appendChild(n)}if(e){const r=document.getElementById("bb-log-container");if(r){const i=document.createElement("div");i.style.cssText=`
        opacity: 0;
        transform: translateX(20px);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border-bottom: 1px solid rgba(0, 255, 255, 0.1);
        padding: 4px 0;
        margin-bottom: 6px;
        text-align: right;
      `;let s="";if(t){const c=Object.entries(t).filter(([d,a])=>a!==void 0&&d!=="__confirmedHighRisk"&&d!=="use").map(([d,a])=>{const l=typeof a=="object"?JSON.stringify(a):String(a),x=l.length>30?l.substring(0,27)+"...":l;return`<span style="color:rgba(0,255,255,0.4);font-size:9px;margin-left:8px;">${d}:</span><span style="color:rgba(255,255,255,0.7);font-size:10px;">${x}</span>`});c.length>0&&(s=`<div style="display:flex;flex-wrap:wrap;justify-content:flex-end;margin-top:2px;">${c.join("")}</div>`)}i.innerHTML=`
        <div style="display:flex;justify-content:flex-end;align-items:center;gap:10px;">
          <span style="color:#fff;font-weight:900;font-size:12px;letter-spacing:1px;">${ne[e.toUpperCase()]||e.toUpperCase().replace("BROWSER_","")}</span>
          <span style="color:#ff00ff;font-weight:bold;animation:bb-blink 0.5s infinite;">></span>
        </div>
        ${s}
      `,r.appendChild(i),requestAnimationFrame(()=>{i.style.opacity="1",i.style.transform="translateX(0)"}),r.childNodes.length>5&&r.removeChild(r.firstChild)}const o=document.getElementById("bb-status-text");if(o){const i=ne[e.toUpperCase()]||e.toUpperCase().replace("BROWSER_","");o.innerText=`AGENT: ${i}`}}}function re(){const e=document.getElementById("browser-bridge-agent-overlay");e&&(e.style.opacity="0",setTimeout(()=>{if(H===0){e.style.display="none";const t=document.getElementById("bb-log-container");t&&(t.innerHTML="")}},300))}async function Re(e){switch(e.tool){case"browser_get_page_text":return W();case"browser_get_page_snapshot":return Be();case"browser_get_page_model":return He(e.params??{});case"browser_get_interactives":return $e(e.params??{});case"browser_find":return je(e.params??{});case"browser_act":return We(e.params??{},e.timeoutMs);case"browser_assert_text":return ge(e.params??{},e.timeoutMs);case"browser_get_selected_text":return Ne();case"browser_get_links":return Oe();case"browser_click":case"browser_find_and_click":return pe(e.params??{});case"browser_hover":return be(e.params??{});case"browser_type":case"browser_find_and_type":return K(e.params??{});case"browser_fill_form":return et(e.params??{});case"browser_clear":return me(e.params??{});case"browser_scroll":return tt(e.params??{});case"browser_press_key":return nt(e.params??{});case"browser_wait_for":return xe(e.params??{},e.timeoutMs);default:throw new Error(`INTERNAL_ERROR: 不支持的页面工具 ${e.tool}`)}}function Ne(){var e;return{text:((e=window.getSelection())==null?void 0:e.toString())??""}}function Oe(){return{links:Array.from(document.querySelectorAll("a[href]")).slice(0,500).map(t=>{const n=t.getBoundingClientRect();return{text:E(t),href:t.href,visible:O(t),rect:{x:n.x,y:n.y,width:n.width,height:n.height}}})}}function Be(){const e=L({visibleOnly:!0}),t=[],n=new Map;for(let r=0;r<e.length;r++){const o=e[r],i=window.getComputedStyle(o),s=parseFloat(i.opacity||"1"),c=o.getBoundingClientRect();if(s<.05||c.width<5&&c.height<5)continue;const d=o.parentElement,a=`${d==null?void 0:d.tagName}-${o.tagName}-${o.getAttribute("role")||R(o)}`,l=n.get(a)||0;if(l<3){const x=_(o,r);x.selectorHint&&x.selectorHint.length>50&&(x.selectorHint=void 0),t.push(x),n.set(a,l+1)}else l===3&&(t.push({elementId:`folded-${r}`,role:"text",tagName:"span",text:`[... ${o.tagName.toLowerCase()} items hidden]`,visible:!0,disabled:!1,rect:N(o)}),n.set(a,l+1));if(t.length>=250)break}return{tabId:-1,url:location.href,title:document.title,text:W().slice(0,1e4),elements:t}}function $e(e){const t=Math.min(g(e,"limit")??80,200),n=e.viewportOnly!==!1,r=L({visibleOnly:!0,viewportOnly:n}).slice(0,t).map(_);return{url:location.href,title:document.title,viewport:{width:window.innerWidth,height:window.innerHeight,scrollX:window.scrollX,scrollY:window.scrollY},elements:r}}function He(e){const t=e.visibleOnly!==!1,n=e.viewportOnly===!0,r=k(g(e,"maxTextLength")??2e3,0,2e4),o=k(g(e,"maxElements")??120,0,300),i=k(g(e,"maxHeadings")??60,0,200),s=k(g(e,"maxRegions")??40,0,120),c=k(g(e,"maxTables")??10,0,50),d=k(g(e,"maxTableRows")??5,0,30),a=W(),l=L({visibleOnly:t,viewportOnly:n}).slice(0,o).map(le);return{tabId:-1,url:location.href,title:document.title,viewport:{width:window.innerWidth,height:window.innerHeight,scrollX:window.scrollX,scrollY:window.scrollY},summary:{textSample:b(a,r),textLength:a.length,truncated:a.length>r},outline:Pe({visibleOnly:t,viewportOnly:n,limit:i}),regions:De({visibleOnly:t,viewportOnly:n,limit:s}),interactives:l,forms:ze({visibleOnly:t,viewportOnly:n,maxElements:o}),tables:Fe({visibleOnly:t,viewportOnly:n,maxTables:c,maxTableRows:d}),messages:Ve({visibleOnly:t,viewportOnly:n}),limits:{maxTextLength:r,maxElements:o,maxHeadings:i,maxRegions:s,maxTables:c,maxTableRows:d}}}function Pe(e){return Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6,[role='heading']")).filter(t=>I(t,e)).slice(0,e.limit).map((t,n)=>({level:ut(t),text:b(E(t),160)??"",elementId:T(t,n),rect:N(t)})).filter(t=>!!t.text)}function De(e){const t=["main","nav","header","footer","aside","section","article","form","[role='main']","[role='navigation']","[role='banner']","[role='contentinfo']","[role='complementary']","[role='region']","[role='dialog']"].join(",");return Array.from(document.querySelectorAll(t)).filter(n=>I(n,e)).slice(0,e.limit).map((n,r)=>({elementId:T(n,r),role:n.getAttribute("role")||dt(n),tagName:n.tagName.toLowerCase(),name:ve(n),textSample:b(E(n),240),rect:N(n)}))}function ze(e){return Array.from(document.querySelectorAll("form")).filter(t=>I(t,e)).slice(0,20).map((t,n)=>{const r=Array.from(t.querySelectorAll(j)).filter(o=>I(o,e)).slice(0,Math.min(e.maxElements,40)).map(le);return{elementId:T(t,n),name:ve(t),fields:r}})}function Fe(e){return Array.from(document.querySelectorAll("table")).filter(t=>I(t,e)).slice(0,e.maxTables).map((t,n)=>{var s;const r=Array.from(t.rows),o=Array.from(t.querySelectorAll("thead th, tr:first-child th")).map(c=>f(c.innerText||c.textContent||"")).filter(Boolean).slice(0,20),i=r.filter(c=>c.cells.length>0&&!c.closest("thead")).slice(0,e.maxTableRows).map(c=>Array.from(c.cells).map(d=>b(f(d.innerText||d.textContent||""),80)??"").slice(0,20));return{elementId:T(t,n),caption:b(((s=t.caption)==null?void 0:s.innerText)||t.getAttribute("aria-label")||void 0,120),headers:o,rowCount:r.filter(c=>!c.closest("thead")).length,sampleRows:i,rect:N(t)}})}function Ve(e){const t=["[role='alert']","[role='status']","[aria-live]",".error",".warning",".success",".toast",".message",".notification"].join(",");return Array.from(document.querySelectorAll(t)).filter(n=>I(n,e)).slice(0,30).map((n,r)=>({elementId:T(n,r),role:n.getAttribute("role")||"message",text:b(E(n),240)??"",rect:N(n)})).filter(n=>!!n.text)}function W(){const e=[],t=r=>{var o;if(r.nodeType===Node.ELEMENT_NODE){const i=r;if(!O(i))return;const s=i.tagName.toLowerCase();if(s==="script"||s==="style"||s==="noscript")return;if(s==="h1"||s==="h2"||s==="h3"||s==="h4"||s==="h5"||s==="h6"){const c=parseInt(s[1]);e.push(`
${"#".repeat(c)} ${i.innerText.trim()}
`)}else if(s==="table")e.push(`
${n(i)}
`);else if(s==="p"||s==="div"||s==="section"||s==="article"){for(const c of Array.from(r.childNodes))t(c);e.push(`
`)}else if(s==="li"){e.push("- ");for(const c of Array.from(r.childNodes))t(c);e.push(`
`)}else for(const c of Array.from(r.childNodes))t(c)}else if(r.nodeType===Node.TEXT_NODE){const i=(o=r.textContent)==null?void 0:o.trim();i&&e.push(i+" ")}};function n(r){const o=Array.from(r.rows).slice(0,20);if(o.length===0)return"";const i=o.map(s=>`| ${Array.from(s.cells).slice(0,10).map(d=>d.innerText.trim().replace(/\|/g,"\\|")).join(" | ")} |`);if(i.length>0){const c=`| ${Array.from(o[0].cells).slice(0,10).map(()=>"---").join(" | ")} |`;i.splice(1,0,c)}return i.join(`
`)}return document.body&&t(document.body),e.join("").replace(/\n{3,}/g,`

`).trim().slice(0,12e4)}function _(e,t){const n=T(e,t),r=e instanceof HTMLInputElement?e:void 0,o=(r==null?void 0:r.type)==="password"?void 0:Q(e);return{elementId:n,role:e.getAttribute("role")||R(e),tagName:e.tagName.toLowerCase(),text:E(e),ariaLabel:e.getAttribute("aria-label")||void 0,placeholder:U(e),value:o,href:e instanceof HTMLAnchorElement?e.href:void 0,visible:O(e),disabled:q(e),selectorHint:Z(e),rect:N(e)}}function le(e,t){const n=_(e,t);return{...n,text:b(n.text,160),ariaLabel:b(n.ariaLabel,120),placeholder:b(n.placeholder,120),value:b(n.value,160)}}function T(e,t){const n=e.getAttribute(F);if(n)return n;const r=`bb-${Date.now().toString(36)}-${t.toString(36)}`;return e.setAttribute(F,r),r}function je(e){const t=Math.min(g(e,"limit")??8,50),n=u(e,"query")??u(e,"text"),r=fe(e).filter(o=>o.score>0).sort((o,i)=>i.score-o.score).slice(0,t).map((o,i)=>({..._(o.element,i),confidence:Math.min(1,Number(o.score.toFixed(2))),reasons:o.reasons}));return{matched:r.length>0,query:n,count:r.length,matches:r}}async function We(e,t){const n=Xe(u(e,"action")),r=u(e,"target"),o=qe(e,r,t);if(n==="assertText"){const c=await ge({...o,text:u(e,"text")??r??u(e,"query"),contains:u(e,"text")??r??u(e,"query")},t);return{ok:!0,action:n,result:c}}if(n==="waitFor"){const c=await xe(o,t);return{ok:!0,action:n,matched:V(c)&&V(c.element)?Ge(c.element):void 0,result:oe(c)}}const i=await Ue(o,n);let s;switch(n){case"click":s=await pe({...o,elementId:i.elementId});break;case"type":s=await K({...o,elementId:i.elementId,text:u(e,"value")??u(e,"text"),replace:e.replace});break;case"hover":s=await be({...o,elementId:i.elementId});break;case"clear":s=await me({...o,elementId:i.elementId});break;default:throw new Error(`INVALID_PARAMS: 不支持的 browser_act 动作 ${n}`)}return{ok:!0,action:n,matched:Ke(i.element,i.confidence,i.reasons),result:oe(s)}}async function Ue(e,t){if(u(e,"elementId")||u(e,"selector")){const i=await P(e,{allowText:t!=="type"&&t!=="clear"});return{element:i,elementId:T(i,0),confidence:1,reasons:["确定定位"]}}const n=ue(e);if(!n)throw new Error("ELEMENT_NOT_FOUND: 未找到元素");const r=Math.min(1,Number(n.score.toFixed(2))),o=g(e,"confidenceThreshold")??Ye(t);if(r<o)throw new Error(`ELEMENT_NOT_FOUND: 最高候选置信度 ${r} 低于阈值 ${o}`);return{element:n.element,elementId:T(n.element,0),confidence:r,reasons:n.reasons}}function qe(e,t,n){return{...e,query:u(e,"query")??t,text:u(e,"text")??t,timeoutMs:g(e,"timeoutMs")??n}}function Xe(e){switch(e){case"click":case"type":case"hover":case"clear":case"waitFor":case"assertText":return e;default:throw new Error("INVALID_PARAMS: browser_act.action 必须是 click、type、hover、clear、waitFor 或 assertText")}}function Ye(e){return e==="click"||e==="type"?.42:.32}function Ke(e,t,n){return{elementId:T(e,0),role:e.getAttribute("role")||R(e),tagName:e.tagName.toLowerCase(),text:b(E(e),80),ariaLabel:b(e.getAttribute("aria-label")??void 0,80),placeholder:b(U(e),80),confidence:t,reasons:n.slice(0,4)}}function Ge(e){return{elementId:String(e.elementId??""),role:String(e.role??""),tagName:String(e.tagName??""),text:b(typeof e.text=="string"?e.text:void 0,80),ariaLabel:b(typeof e.ariaLabel=="string"?e.ariaLabel:void 0,80),placeholder:b(typeof e.placeholder=="string"?e.placeholder:void 0,80)}}function oe(e){return V(e)?Object.fromEntries(Object.entries(e).filter(([t])=>t!=="element"&&t!=="fields")):e}async function P(e,t={}){const n=t.timeoutMs??g(e,"timeoutMs")??3e3,r=Date.now();let o;for(;Date.now()-r<=n;)try{return de(e,t)}catch(i){o=i,await y(100)}throw o instanceof Error?o:new Error("ELEMENT_NOT_FOUND: 未找到元素")}function de(e,t={}){const n=u(e,"elementId"),r=u(e,"selector"),o=u(e,"query"),i=u(e,"text"),s=u(e,"role"),c=u(e,"ariaLabel"),d=u(e,"placeholder"),a=u(e,"href");let l=null;if(n&&(l=document.querySelector(`[${F}="${S(n)}"]`),!l&&/^\d+$/.test(n)&&(l=document.querySelector(`[data-bb-temp-id="${S(n)}"]`))),!l&&r&&(l=Je(r)),!l&&o&&(l=ie({...e,text:i??o})),!l&&i&&t.allowText!==!1&&(l=we(i)),!l&&c&&(l=ce("aria-label",c)),!l&&d&&(l=ce("placeholder",d)),!l&&a&&(l=ct(a)),!l&&s&&(l=ye(s,t.allowText===!1?void 0:i)),l||(l=ie(e)),!l||!(l instanceof HTMLElement))throw new Error("ELEMENT_NOT_FOUND: 未找到元素");return l}function Je(e){try{if(/^\d+$/.test(e))return document.querySelector(`[data-bb-temp-id="${S(e)}"]`);if(e.startsWith("text="))return we(e.slice(5));if(e.startsWith("xpath=")){const r=document.evaluate(e.slice(6),document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue;return r instanceof HTMLElement?r:null}if(e.startsWith("role=")){const n=e.match(/^role=([^\[]+)(?:\[name=(?:"([^"]+)"|'([^']+)')\])?$/);if(n){const r=n[1],o=n[2]||n[3];return ye(r,o)}}if(e.startsWith("id="))return document.getElementById(e.slice(3));if(e.startsWith("data-testid="))return document.querySelector(`[data-testid="${S(e.slice(12))}"]`);const t=e.startsWith("css=")?e.slice(4):e;return document.querySelector(t)}catch(t){return console.warn("[BrowserBridge] 选择器解析失败:",e,t),null}}function ie(e){var t;return((t=ue(e))==null?void 0:t.element)??null}function ue(e){return fe(e).filter(t=>t.score>0).sort((t,n)=>n.score-t.score)[0]??null}function fe(e){const t=f(u(e,"query")??u(e,"text")??""),n=f(u(e,"role")??""),r=f(u(e,"ariaLabel")??""),o=f(u(e,"placeholder")??""),i=u(e,"href"),s=f(u(e,"nearText")??""),c=e.visibleOnly!==!1,d=e.viewportOnly===!0;return L({visibleOnly:c,viewportOnly:d}).map(a=>{const l=f(E(a)??""),x=f(a.getAttribute("role")||R(a)),p=f(a.getAttribute("aria-label")??""),w=f(a.getAttribute("title")??""),B=f(U(a)??""),D=f(Q(a)??""),Te=a instanceof HTMLAnchorElement?a.href:void 0,ee=f(Ee(a));let h=0;const m=[];return t&&(h+=v(t,l,.62,"文本",m),h+=v(t,p,.58,"aria-label",m),h+=v(t,B,.56,"placeholder",m),h+=v(t,w,.46,"title",m),h+=v(t,D,.28,"value",m),h+=v(t,ee,.22,"附近文本",m)),n&&x===n&&(h+=.22,m.push("role 精确匹配")),r&&(h+=v(r,p,.5,"aria-label",m)),o&&(h+=v(o,B,.5,"placeholder",m)),i&&(Te===i||a.getAttribute("href")===i)&&(h+=.5,m.push("href 精确匹配")),s&&(h+=v(s,ee,.24,"nearText",m)),$(a)&&(h+=.08,m.push("当前视口")),q(a)&&(h-=.45,m.push("已禁用降权")),{element:a,score:h,reasons:m}})}function v(e,t,n,r,o){return!e||!t?0:t===e?(o.push(`${r} 精确匹配`),n):t.includes(e)?(o.push(`${r} 包含匹配`),n*.78):e.includes(t)&&t.length>=2?(o.push(`${r} 被查询包含`),n*.5):0}async function pe(e){const t=await P(e,{allowText:!0});if(e.__confirmedHighRisk!==!0&&await Ze()&&await Qe(t),await G(t),t.scrollIntoView({block:"center",inline:"center"}),await y(150),J(t),C(t,"mouseover"),C(t,"mousemove"),C(t,"mousedown"),t.click(),C(t,"mouseup"),e.forceCdp===!0){const n=t.getBoundingClientRect();await chrome.runtime.sendMessage({type:"browser_bridge_cdp_input",action:"click",params:{x:n.left+n.width/2,y:n.top+n.height/2}})}return{clicked:!0,element:_(t,0)}}async function be(e){const t=await P(e,{allowText:!0});return await G(t),t.scrollIntoView({block:"center",inline:"center"}),await y(150),J(t),C(t,"mouseover"),C(t,"mouseenter"),C(t,"mousemove"),t.dispatchEvent(new MouseEvent("mouseover",{bubbles:!0,cancelable:!0,view:window})),t.dispatchEvent(new MouseEvent("mouseenter",{bubbles:!1,cancelable:!0,view:window})),t.dispatchEvent(new MouseEvent("mousemove",{bubbles:!0,cancelable:!0,view:window})),{hovered:!0,element:_(t,0)}}async function K(e){const t=await P(e,{allowText:!0}),n=u(e,"text")??"",r=e.replace===!0;if(at(t),await G(t),t.scrollIntoView({block:"center",inline:"center"}),await y(150),J(t,"#3b82f6"),t.focus(),r&&(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?t.value="":t.isContentEditable&&(t.textContent="")),e.forceCdp===!0)await chrome.runtime.sendMessage({type:"browser_bridge_cdp_input",action:"type",params:{text:n}});else for(const o of n){const i={key:o,code:`Key${o.toUpperCase()}`,bubbles:!0};t.dispatchEvent(new KeyboardEvent("keydown",i)),t.dispatchEvent(new KeyboardEvent("keypress",i)),t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?(t.value+=o,t.dispatchEvent(new Event("input",{bubbles:!0}))):t.isContentEditable&&(t.textContent+=o,t.dispatchEvent(new Event("input",{bubbles:!0}))),t.dispatchEvent(new KeyboardEvent("keyup",i)),await y(Math.random()*20+10)}return t.dispatchEvent(new Event("change",{bubbles:!0})),{typed:!0,element:_(t,0)}}async function G(e,t=3e3){const n=Date.now();let r,o=0;for(;Date.now()-n<t;){if(!O(e)){await y(150);continue}if(q(e)){await y(150);continue}const i=e.getBoundingClientRect();if(r&&Math.abs(i.top-r.top)<.5&&Math.abs(i.left-r.left)<.5&&Math.abs(i.width-r.width)<.5&&Math.abs(i.height-r.height)<.5?o++:o=0,r=i,o<2){await y(100);continue}const s=[{x:i.left+i.width/2,y:i.top+i.height/2},{x:i.left+2,y:i.top+2},{x:i.right-2,y:i.top+2},{x:i.left+2,y:i.bottom-2},{x:i.right-2,y:i.bottom-2}];let c=!0;for(const d of s){const a=document.elementFromPoint(d.x,d.y);if(a&&(e===a||e.contains(a)||a.contains(e))){c=!1;break}}if(c){await y(200);continue}return}throw new Error(`ACTION_TIMEOUT: 元素在 ${t}ms 内未达到可交互状态（可能被遮挡、正在移动或不可见）`)}function J(e,t="#ef4444"){const n=e.getBoundingClientRect(),r=document.createElement("div");if(r.style.cssText=`
    position: fixed;
    top: ${n.top+n.height/2}px;
    left: ${n.left+n.width/2}px;
    width: 2px;
    height: 2px;
    background: transparent;
    border: 4px solid ${t};
    border-radius: 50%;
    pointer-events: none;
    z-index: 2147483647;
    transform: translate(-50%, -50%);
    animation: bb-ripple-animation 0.6s ease-out forwards;
  `,!document.getElementById("bb-ripple-style")){const o=document.createElement("style");o.id="bb-ripple-style",o.textContent=`
      @keyframes bb-ripple-animation {
        0% { width: 0; height: 0; opacity: 1; border-width: 4px; }
        100% { width: 100px; height: 100px; opacity: 0; border-width: 1px; }
      }
    `,document.head.appendChild(o)}document.body.appendChild(r),setTimeout(()=>r.remove(),600)}async function Qe(e){const t=[E(e),e.getAttribute("aria-label"),e.getAttribute("title"),e.getAttribute("value")].filter(o=>!!o).join(" "),n=Ee(e),r=`${t} ${n}`;if(_e.some(o=>o.test(r))&&!await he(`Agent 试图执行高风险浏览器操作。

目标元素及上下文可能涉及敏感动作（如删除、支付）：

【元素文本】: ${t||"(空)"}
【附近文本】: ${b(n,100)||"(无)"}`))throw new Error("USER_REJECTED: 用户已取消高风险浏览器操作")}function he(e){return new Promise(t=>{var x;(x=document.querySelector("#browser-bridge-confirm-overlay"))==null||x.remove();const n=document.createElement("div");n.id="browser-bridge-confirm-overlay",n.style.cssText=["position:fixed","inset:0","z-index:2147483647","display:flex","align-items:center","justify-content:center","background:rgba(11,18,32,.48)","font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"].join(";");const r=document.createElement("div");r.style.cssText=["box-sizing:border-box","width:min(420px,calc(100vw - 32px))","border-radius:8px","background:#fff","box-shadow:0 18px 50px rgba(0,0,0,.28)","padding:18px","color:#172026"].join(";");const o=document.createElement("h2");o.textContent="确认浏览器操作",o.style.cssText="margin:0 0 10px;font-size:18px;line-height:1.3";const i=document.createElement("p");i.textContent=e,i.style.cssText="margin:0 0 14px;font-size:13px;line-height:1.5;color:#3c4852;white-space:pre-line";const s=document.createElement("p");s.textContent=location.href,s.style.cssText=["margin:0 0 16px","padding:8px","border-radius:6px","background:#f3f6f8","font-size:12px","line-height:1.4","word-break:break-all","color:#53616c"].join(";");const c=document.createElement("div");c.style.cssText="display:flex;gap:10px;justify-content:flex-end";const d=document.createElement("button");d.textContent="取消",d.style.cssText=se("#eef2f5","#172026");const a=document.createElement("button");a.textContent="确认执行",a.style.cssText=se("#b42318","#fff");const l=p=>{n.remove(),t(p)};d.addEventListener("click",()=>l(!1),{once:!0}),a.addEventListener("click",()=>l(!0),{once:!0}),n.addEventListener("click",p=>{p.target===n&&l(!1)}),c.append(d,a),r.append(o,i,s,c),n.append(r),document.documentElement.append(n)})}function se(e,t){return["border:0","border-radius:6px","padding:8px 12px","font-size:13px","cursor:pointer",`background:${e}`,`color:${t}`].join(";")}async function Ze(){const e=await chrome.storage.local.get("blockHighRiskActions");return typeof e.blockHighRiskActions=="boolean"?e.blockHighRiskActions:!0}async function et(e){const t=Array.isArray(e.fields)?e.fields:void 0;if(!(t!=null&&t.length))throw new Error("INVALID_PARAMS: fields 参数必填");if(t.length>30)throw new Error("INVALID_PARAMS: fields 最多支持 30 项");const n=[];for(const[r,o]of t.entries()){if(!V(o)||typeof o.value!="string"){n.push({index:r,ok:!1,error:"字段必须包含 value"});continue}try{const i=await K({...o,text:o.value,replace:o.replace!==!1});n.push({index:r,ok:!0,element:i.element})}catch(i){const s=i instanceof Error?i.message:String(i);n.push({index:r,ok:!1,error:s})}}return{filled:n.every(r=>r.ok),fields:n}}async function me(e){const t=await P(e,{allowText:!1});return it(t,""),{cleared:!0,element:_(t,0)}}function tt(e){const t=u(e,"direction")||"down",n=g(e,"amount")??Math.round(window.innerHeight*.8),r=t==="up"||t==="left"?-n:n;return t==="left"||t==="right"?window.scrollBy({left:r,behavior:"smooth"}):window.scrollBy({top:r,behavior:"smooth"}),{scrolled:!0}}function nt(e){const t=u(e,"key");if(!t)throw new Error("INVALID_PARAMS: key 参数必填");const n=document.activeElement instanceof HTMLElement?document.activeElement:document.body;for(const r of["keydown","keypress","keyup"])n==null||n.dispatchEvent(new KeyboardEvent(r,{bubbles:!0,cancelable:!0,key:t}));return rt(t,n),{pressed:!0,key:t}}function rt(e,t){if(e==="Enter"){if(t instanceof HTMLButtonElement){t.click();return}const n=t==null?void 0:t.closest("form");n instanceof HTMLFormElement&&n.requestSubmit();return}e==="Tab"&&ot()}function ot(e){var o;const t=L({visibleOnly:!0}).filter(i=>!q(i)&&ft(i)),r=((document.activeElement instanceof HTMLElement?t.indexOf(document.activeElement):-1)+1)%t.length;(o=t[r])==null||o.focus()}async function ge(e,t){const n=u(e,"text")??u(e,"contains");if(!n)throw new Error("INVALID_PARAMS: text 或 contains 参数必填");const r=g(e,"timeoutMs")??t??5e3,o=Date.now();for(;Date.now()-o<r;){if(W().includes(n))return{asserted:!0,text:n};await y(100)}throw new Error(`ACTION_TIMEOUT: ${r}ms 内未出现文本 ${n}`)}async function xe(e,t){const n=g(e,"timeoutMs")??t??5e3,r=Date.now();for(;Date.now()-r<n;)try{const o=de(e);return{found:!0,element:_(o,0)}}catch{await y(100)}throw new Error(`ACTION_TIMEOUT: ${n}ms 内未找到元素`)}function it(e,t,n){if(e.focus(),e instanceof HTMLSelectElement){st(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}));return}if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){const r=t;e.value=r,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}));return}if(e.isContentEditable){e.textContent=t,e.dispatchEvent(new Event("input",{bubbles:!0}));return}throw new Error("UNSUPPORTED_PAGE: 目标元素不支持文本输入")}function st(e,t){const n=Array.from(e.options).find(r=>r.value===t||f(r.label)===f(t)||f(r.textContent??"")===f(t));if(!n)throw new Error(`ELEMENT_NOT_FOUND: 下拉选项不存在 ${t}`);e.value=n.value}function we(e){const t=f(e);return Array.from(document.querySelectorAll(j)).find(r=>f(E(r)??"").includes(t))??null}function ce(e,t){const n=f(t),r=`[${e}]`;return Array.from(document.querySelectorAll(r)).find(i=>f(i.getAttribute(e)??"")===n)??null}function ct(e){return Array.from(document.querySelectorAll("a[href]")).find(n=>n.href===e||n.getAttribute("href")===e)??null}function ye(e,t){const n=f(e),r=t?f(t):void 0;return Array.from(document.querySelectorAll(j)).find(i=>R(i)===n||i.getAttribute("role")===n?r?f(E(i)??"").includes(r):!0:!1)??null}function L(e={}){const t=new Set;return Array.from(document.querySelectorAll(j)).filter(r=>!(t.has(r)||(t.add(r),e.visibleOnly!==!1&&!O(r))||e.viewportOnly&&!$(r))).sort((r,o)=>{const i=$(r)?0:1,s=$(o)?0:1;if(i!==s)return i-s;const c=r.getBoundingClientRect(),d=o.getBoundingClientRect();return c.top-d.top||c.left-d.left})}function E(e){return f(e.innerText||e.textContent||"")||void 0}function Ee(e){var n,r,o,i,s,c,d,a;return[(n=e.parentElement)==null?void 0:n.innerText,(r=e.closest("label"))==null?void 0:r.textContent,(o=e.closest("li"))==null?void 0:o.textContent,(i=e.closest("tr"))==null?void 0:i.textContent,(c=(s=e.closest("section"))==null?void 0:s.querySelector("h1,h2,h3,h4"))==null?void 0:c.textContent,(a=(d=e.closest("form"))==null?void 0:d.querySelector("label"))==null?void 0:a.textContent].filter(l=>!!l).map(l=>l.slice(0,500)).join(" ")}function Q(e){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement)return e.value||void 0}function U(e){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)return e.placeholder||void 0}function at(e){if(!lt(e))throw new Error("ELEMENT_NOT_FOUND: 未找到可输入的表单控件")}function lt(e){if(e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement)return!0;if(e instanceof HTMLInputElement){const t=e.type.toLowerCase();return!["button","submit","reset","checkbox","radio","file","image","hidden"].includes(t)}return e.isContentEditable||e.getAttribute("role")==="textbox"}function R(e){const t=e.tagName.toLowerCase();if(t==="a")return"link";if(t==="button")return"button";if(t==="textarea")return"textbox";if(t==="select")return"combobox";if(t==="input"){const n=e.type;return n==="checkbox"?"checkbox":n==="radio"?"radio":n==="submit"||n==="button"?"button":"textbox"}return"generic"}function dt(e){const t=e.tagName.toLowerCase();return t==="main"?"main":t==="nav"?"navigation":t==="header"?"banner":t==="footer"?"contentinfo":t==="aside"?"complementary":t==="form"?"form":t==="article"?"article":t==="section"?"region":R(e)}function ut(e){const n=e.tagName.toLowerCase().match(/^h([1-6])$/);if(n)return Number(n[1]);const r=Number(e.getAttribute("aria-level"));return Number.isFinite(r)&&r>0?r:2}function ve(e){var o;const t=e.getAttribute("aria-labelledby"),n=t==null?void 0:t.split(/\s+/).map(i=>{var s;return((s=document.getElementById(i))==null?void 0:s.textContent)??""}).join(" "),r=f(n||e.getAttribute("aria-label")||e.getAttribute("title")||((o=e.querySelector("h1,h2,h3,h4,h5,h6,legend"))==null?void 0:o.textContent)||"");return b(r||void 0,160)}function I(e,t){return!(t.visibleOnly&&!O(e)||t.viewportOnly&&!$(e))}function N(e){const t=e.getBoundingClientRect();return{x:Math.round(t.x),y:Math.round(t.y),width:Math.round(t.width),height:Math.round(t.height)}}function Z(e){if(e.id)return`#${S(e.id)}`;const t=e.getAttribute("data-testid");if(t)return`[data-testid="${S(t)}"]`;const n=e.getAttribute("name");if(n)return`${e.tagName.toLowerCase()}[name="${S(n)}"]`}function O(e){const t=window.getComputedStyle(e),n=e.getBoundingClientRect();return t.display!=="none"&&t.visibility!=="hidden"&&Number(t.opacity)!==0&&n.width>0&&n.height>0}function $(e){const t=e.getBoundingClientRect();return t.bottom>=0&&t.right>=0&&t.top<=window.innerHeight&&t.left<=window.innerWidth}function q(e){return e.hasAttribute("disabled")||e.getAttribute("aria-disabled")==="true"}function ft(e){return e.tabIndex>=0||e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement||e instanceof HTMLButtonElement||e instanceof HTMLAnchorElement||e.isContentEditable}function C(e,t){const n=e.getBoundingClientRect();e.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,view:window,clientX:n.left+n.width/2,clientY:n.top+n.height/2}))}function V(e){return typeof e=="object"&&e!==null}function f(e){return e.replace(/\s+/g," ").trim()}function b(e,t){if(e)return e.length>t?`${e.slice(0,t-1)}…`:e}function k(e,t,n){return Math.min(Math.max(e,t),n)}function u(e,t){const n=e[t];return typeof n=="string"?n:void 0}function g(e,t){const n=e[t];return typeof n=="number"&&Number.isFinite(n)?n:void 0}function S(e){return"CSS"in window&&typeof CSS.escape=="function"?CSS.escape(e):e.replace(/"/g,'\\"')}function y(e){return new Promise(t=>window.setTimeout(t,e))}
