const E="ws://127.0.0.1:17321",R="0.2.1",s="0.1.0";export{E as D,R as E,s as P};
